"""sgl.sglalign — 调换感知对齐测试"""

from sgl import sglalign
from sgl._types import AlignmentResult, ShuffleGroup
from sgl.sglsim import hybrid_similarity


def identity_sim(a, b):
    return 1.0 if a == b else 0.0


class TestReorderalign:
    def test_normal_order(self):
        a = sglalign.Aligner()
        r = a.reorderalign(["a", "b", "c"], ["a", "b", "c"], identity_sim)
        assert r.summary().get("shuffled", 0) == 0
        assert all(not p.is_shuffled for p in r.pairs)

    def test_detect_swap(self):
        a = sglalign.Aligner()
        r = a.reorderalign(["A", "B", "C"], ["A", "C", "B"], hybrid_similarity)
        assert len(r.pairs) == 3
        assert all(not p.is_gap for p in r.pairs)
        shuffled = [p for p in r.pairs if p.is_shuffled]
        assert len(shuffled) == 2
        assert r.shuffle_groups is not None
        assert len(r.shuffle_groups) >= 1

    def test_summary_shuffle_count(self):
        a = sglalign.Aligner()
        r = a.reorderalign(["A", "B", "C"], ["A", "C", "B"], hybrid_similarity)
        s = r.summary()
        assert s.get("shuffled", 0) == 2

    def test_large_swap_block(self):
        a = sglalign.Aligner()
        r = a.reorderalign(["A", "B", "C"], ["C", "A", "B"], hybrid_similarity)
        assert len(r.pairs) == 3
        assert sum(1 for p in r.pairs if p.is_shuffled) == 3

    def test_partial_swap(self):
        a = sglalign.Aligner()
        r = a.reorderalign(["X", "Y", "P", "Q"], ["X", "Y", "Q", "P"], hybrid_similarity)
        assert not r.pairs[0].is_shuffled
        assert not r.pairs[1].is_shuffled
        assert r.pairs[2].is_shuffled
        assert r.pairs[3].is_shuffled

    def test_with_insertion(self):
        a = sglalign.Aligner()
        r = a.reorderalign(["A", "B", "D"], ["A", "C", "D", "B"], hybrid_similarity)
        states = [p.state for p in r.pairs]
        assert "insert" in states or "delete" in states
