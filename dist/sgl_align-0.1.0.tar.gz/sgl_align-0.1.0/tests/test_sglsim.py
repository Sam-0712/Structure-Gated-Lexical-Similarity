"""sgl.sglsim — 混合相似度测试"""

import pytest
from sgl import sglsim


class TestHybridSimilarity:
    def test_empty_strings(self):
        assert sglsim.hybrid_similarity("", "") == 0.0
        assert sglsim.hybrid_similarity("a", "") == 0.0
        assert sglsim.hybrid_similarity("", "b") == 0.0

    def test_identical(self):
        assert sglsim.hybrid_similarity("\u4f60\u597d\u4e16\u754c", "\u4f60\u597d\u4e16\u754c") > 0.99

    def test_subset(self):
        score = sglsim.hybrid_similarity("\u4f60\u597d\u4e16\u754c", "\u4f60\u597d")
        assert 0.0 < score < 1.0

    def test_unrelated(self):
        s1 = sglsim.hybrid_similarity("\u5b8c\u5168\u4e0d\u540c", "\u6beb\u4e0d\u76f8\u5173")
        s2 = sglsim.hybrid_similarity("\u82f9\u679c\u624b\u673a", "\u6570\u5b66\u516c\u5f0f")
        assert s1 < 0.5
        assert s2 < 0.5

    def test_synonym(self):
        score = sglsim.hybrid_similarity("\u79cb\u5929\u975e\u5e38\u7f8e\u4e3d", "\u79cb\u8272\u6781\u7f8e")
        assert score > 0.3

    def test_word_shuffle(self):
        s_fwd = sglsim.hybrid_similarity("\u4f60\u597d\u4e16\u754c", "\u4e16\u754c\u4f60\u597d")
        s_rev = sglsim.hybrid_similarity("\u6625\u590f\u79cb\u51ac", "\u51ac\u79cb\u590f\u6625")
        assert s_fwd > 0.1
        assert s_rev > 0.1

    def test_cache_hits(self):
        before = sglsim.cacheinfo().hits
        for _ in range(10):
            sglsim.hybrid_similarity("\u4f60\u597d\u4e16\u754c", "\u4f60\u597d\u4e16\u754c")
        after = sglsim.cacheinfo().hits
        assert after > before

    def test_cache_clear(self):
        sglsim.hybrid_similarity("a", "b")
        assert sglsim.cacheinfo().currsize > 0
        sglsim.cacheclear()
        assert sglsim.cacheinfo().currsize == 0


class TestHybridDetail:
    def test_detailed_returns_dataclass(self):
        result = sglsim.hybriddetail("\u4f60\u597d\u4e16\u754c", "\u4e16\u754c\u4f60\u597d")
        assert result.score > 0
        assert isinstance(result.dice_score, float)
        assert isinstance(result.lcs_score, float)
        assert isinstance(result.roc_score, float)

    def test_detailed_to_dict(self):
        result = sglsim.hybriddetail("abc", "abd")
        d = result.to_dict()
        assert "score" in d
        assert "dice_score" in d

    def test_detailed_to_json(self):
        result = sglsim.hybriddetail("abc", "abd")
        j = result.to_json()
        assert '"score"' in j

    def test_detailed_summary(self):
        result = sglsim.hybriddetail("abc", "abd")
        s = result.summary()
        assert "score" in s
        assert "dice" in s
        assert "roc" in s
