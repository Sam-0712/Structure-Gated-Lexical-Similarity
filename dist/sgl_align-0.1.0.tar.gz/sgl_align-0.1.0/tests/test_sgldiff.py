"""sgl.sgldiff — 字符级差异对齐测试"""

import pytest
from sgl import sgldiff
from sgl._types import CharDiff, DiffBlock, RichDiffResult
from sgl.sglalign import Aligner
from sgl.sglsim import hybrid_similarity


class TestChardiff:
    def test_empty_source(self):
        diffs = sgldiff.chardiff("", "abc")
        assert len(diffs) == 3
        assert all(d.diff_type == "insert" for d in diffs)

    def test_empty_target(self):
        diffs = sgldiff.chardiff("abc", "")
        assert len(diffs) == 3
        assert all(d.diff_type == "delete" for d in diffs)

    def test_identical(self):
        diffs = sgldiff.chardiff("abc", "abc")
        assert all(d.diff_type == "equal" for d in diffs)
        assert len(diffs) == 3

    def test_single_char_change(self):
        diffs = sgldiff.chardiff("abc", "adc")
        types = [d.diff_type for d in diffs]
        assert "equal" in types
        ts = set(types)
        assert "delete" in ts
        assert "insert" in ts

    def test_cluster_merge(self):
        diffs = sgldiff.chardiff("abcde", "abxyde")
        types = [d.diff_type for d in diffs]
        de = None
        is_ = None
        for i, t in enumerate(types):
            if t == "delete" and de is None: de = i
            if t == "insert" and is_ is None: is_ = i
        if de is not None and is_ is not None:
            assert is_ > de


def custom_sim(a, b):
    return 1.0 if a == b else 0.0


class TestRichdiff:
    def test_all_equal(self):
        aligner = Aligner()
        seq1 = ["hello", "world"]
        seq2 = ["hello", "world"]
        result = aligner.align(seq1, seq2, custom_sim)
        rich = sgldiff.richdiff(result.pairs, similarity_func=custom_sim)
        assert isinstance(rich, RichDiffResult)
        assert all(b.block_type == "equal" for b in rich.blocks)

    def test_insert_block(self):
        aligner = Aligner()
        seq1 = ["hello"]
        seq2 = ["hello", "world"]
        result = aligner.align(seq1, seq2, custom_sim)
        rich = sgldiff.richdiff(result.pairs, similarity_func=custom_sim)
        types = [b.block_type for b in rich.blocks]
        assert "insert" in types

    def test_delete_block(self):
        aligner = Aligner()
        seq1 = ["hello", "world"]
        seq2 = ["hello"]
        result = aligner.align(seq1, seq2, custom_sim)
        rich = sgldiff.richdiff(result.pairs, similarity_func=custom_sim)
        types = [b.block_type for b in rich.blocks]
        assert "delete" in types

    def test_summary(self):
        aligner = Aligner()
        seq1 = ["hello", "world", "foo"]
        seq2 = ["hello", "earth", "foo"]
        result = aligner.align(seq1, seq2, custom_sim)
        rich = sgldiff.richdiff(result.pairs, similarity_func=custom_sim)
        s = rich.summary()
        assert "equal" in s
        assert "modify" in s

    def test_to_diff_text(self):
        aligner = Aligner()
        seq1 = ["hello"]
        seq2 = ["world"]
        result = aligner.align(seq1, seq2, custom_sim)
        rich = sgldiff.richdiff(result.pairs, similarity_func=custom_sim)
        text = rich.to_diff_text()
        assert "- hello" in text
        assert "+ world" in text
