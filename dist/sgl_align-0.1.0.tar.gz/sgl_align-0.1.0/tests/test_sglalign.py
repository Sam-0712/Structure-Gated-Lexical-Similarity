"""sgl.sglalign — Needleman-Wunsch 对齐测试"""

import pytest
from sgl import sglalign
from sgl.sglsim import hybrid_similarity
from sgl._types import AlignmentResult, AlignedPair


def identity_sim(a, b):
    return 1.0 if a == b else 0.0


class TestAlignerInit:
    def test_default_params(self):
        a = sglalign.Aligner()
        assert a.gap_open == -1.5
        assert a.gap_extend == -0.2
        assert a.mismatch_threshold == 0.2

    def test_custom_params(self):
        a = sglalign.Aligner(gap_open=-2.0, gap_extend=-0.5, mismatch_threshold=0.3)
        assert a.gap_open == -2.0
        assert a.gap_extend == -0.5
        assert a.mismatch_threshold == 0.3


class TestAlign:
    def test_identical_sequences(self):
        seq = ["a", "b", "c"]
        a = sglalign.Aligner()
        result = a.align(seq, seq, identity_sim)
        assert len(result.pairs) == 3
        assert all(p.state == "match" for p in result.pairs)
        assert result.score > 0

    def test_insertion(self):
        seq1 = ["a", "c"]
        seq2 = ["a", "b", "c"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        states = [p.state for p in result.pairs]
        assert "match" in states
        assert "insert" in states

    def test_deletion(self):
        seq1 = ["a", "b", "c"]
        seq2 = ["a", "c"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        states = [p.state for p in result.pairs]
        assert "match" in states
        assert "delete" in states

    def test_completely_different(self):
        seq1 = ["a", "b"]
        seq2 = ["x", "y"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        assert len(result.pairs) >= 2

    def test_return_type(self):
        seq1 = ["hello", "world"]
        seq2 = ["hello", "world"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        assert isinstance(result, AlignmentResult)
        assert isinstance(result.pairs, list)
        assert isinstance(result.pairs[0], AlignedPair)

    def test_matrices_present(self):
        seq1 = ["a", "b"]
        seq2 = ["a", "b"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        assert result.dp_matrix is not None
        assert result.matrix_m is not None
        assert result.matrix_x is not None
        assert result.matrix_y is not None
        assert len(result.dp_matrix) == 3
        assert len(result.dp_matrix[0]) == 3

    def test_backtrace_path(self):
        seq1 = ["a", "b"]
        seq2 = ["a", "b"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        assert result.backtrace_path is not None
        assert len(result.backtrace_path) > 0
        assert result.backtrace_path[0] == (0, 0, "M")
        assert result.backtrace_path[-1] == (2, 2, "M")

    def test_aligned_pair_fields(self):
        seq1 = ["a"]
        seq2 = ["b"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        p = result.pairs[0]
        assert hasattr(p, "source")
        assert hasattr(p, "target")
        assert hasattr(p, "similarity")
        assert hasattr(p, "is_gap")
        assert hasattr(p, "state")


class TestAlignfb:
    def test_fb_matrix_shape(self):
        seq1 = ["hello", "world"]
        seq2 = ["hello", "earth"]
        a = sglalign.Aligner()
        result = a.alignfb(seq1, seq2, hybrid_similarity)
        assert result.fb_matrix is not None
        assert len(result.fb_matrix) == 3
        assert len(result.fb_matrix[0]) == 3

    def test_fb_values_are_finite(self):
        seq1 = ["\u4eca\u5929\u5929\u6c14\u5f88\u597d"]
        seq2 = ["\u4eca\u65e5\u5929\u6c14\u4e0d\u9519"]
        a = sglalign.Aligner()
        result = a.alignfb(seq1, seq2, hybrid_similarity)
        import math
        for row in result.fb_matrix:
            for val in row:
                assert math.isfinite(val)


class TestResultSerialization:
    def test_to_dict(self):
        seq1 = ["a", "b"]
        seq2 = ["a", "c"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        d = result.to_dict()
        assert "pairs" in d
        assert "score" in d
        assert "dp_matrix" in d

    def test_to_json(self):
        seq1 = ["a", "b"]
        seq2 = ["a", "b"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        j = result.to_json()
        assert '"pairs"' in j
        import json
        json.loads(j)

    def test_summary(self):
        seq1 = ["a", "b", "c", "d"]
        seq2 = ["a", "x", "c", "e"]
        a = sglalign.Aligner()
        result = a.align(seq1, seq2, identity_sim)
        s = result.summary()
        assert "score" in s
        assert "match" in s
