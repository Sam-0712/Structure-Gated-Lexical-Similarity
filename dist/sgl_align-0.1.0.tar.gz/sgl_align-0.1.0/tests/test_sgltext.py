"""sgl.sgltext — 句子切分测试"""

from sgl import sgltext


class TestSplitsents:
    def test_simple(self):
        assert sgltext.splitsents("a\u3002b\u3002") == ["a\u3002", "b\u3002"]

    def test_chinese_enders(self):
        r = sgltext.splitsents("\u4f60\u597d\u3002\u518d\u89c1\uff01")
        assert r == ["\u4f60\u597d\u3002", "\u518d\u89c1\uff01"]

    def test_english_enders(self):
        r = sgltext.splitsents("Hi. Bye!")
        assert r == ["Hi.", "Bye!"]

    def test_quotes(self):
        r = sgltext.splitsents('"\u4f60\u597d\u3002"\u4ed6\u8bf4\u3002')
        assert r == ['"\u4f60\u597d\u3002"', "\u4ed6\u8bf4\u3002"]

    def test_newline(self):
        r = sgltext.splitsents("a\u3002\nb\u3002\n\nc\u3002")
        assert r == ["a\u3002", "b\u3002", "c\u3002"]

    def test_empty(self):
        assert sgltext.splitsents("") == []
        assert sgltext.splitsents("  ") == []

    def test_no_ender(self):
        assert sgltext.splitsents("\u4f60\u597d") == ["\u4f60\u597d"]

    def test_ellipsis(self):
        r = sgltext.splitsents("\u4f60\u597d\u2026\u2026\u4e16\u754c\u2026\u2026")
        assert r == ["\u4f60\u597d\u2026\u2026", "\u4e16\u754c\u2026\u2026"]

    def test_min_len(self):
        r = sgltext.splitsents("\u4e00\u4e8c\u4e09\u56db\u3002\u4e94\u516d\u4e03\u516b\u3002\u4e5d\u5341\u3002", minlen=4)
        assert r == ["\u4e00\u4e8c\u4e09\u56db\u3002", "\u4e94\u516d\u4e03\u516b\u3002"]

    def test_min_len_fallback(self):
        r = sgltext.splitsents("a\u3002b\u3002\u597d\u3002", minlen=2)
        assert r == ["a\u3002b\u3002\u597d\u3002"]

    def test_countsents(self):
        assert sgltext.countsents("a\u3002b\u3002c\u3002") == 3
